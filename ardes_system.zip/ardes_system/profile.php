<?php 
	echo 'Here I am';
	print_r($_POST);
?>