<?php
function create_database_connection(){
	$db_credentials = array(
			'host_name' => 'localhost',
			'username' => 'admin_user',
			'password' => 'admin_pass',
			'database_name' => 'ardes_system'

	);

	$connection_res = array();


	
	$mysqli = new mysqli($db_credentials['host_name'], $db_credentials['username'], $db_credentials['password'], $db_credentials['database_name']);

	if ($mysqli->connect_errno) {
		$connection_res['success'] = false;
		$connection_res['ErrorMsg'] = "Грешка при свързване към базата от данни: ";//.$mysqli->connect_error;
	}else{
		$connection_res['success'] = true;
		$connection_res['connection'] = $mysqli;
	}

	return $connection_res;
}

?>