<?php
require 'database_functions.php';

function check_username($db_conn,$username){
	
	$user_exist = false;

	$sql = "SELECT count(id) as users_count FROM users where username = '".$username."'";
	
	$result = $db_conn['connection']->query($sql);

	$row = $result->fetch_assoc();
	
	if ($row['users_count'] > 0) {
		$user_exist = true;
	} else {
		$user_exist = false;
	}
	return $user_exist;

}

function register_user(){


	$username = $_POST['username'];
	$password = password_hash($_POST['password'],PASSWORD_DEFAULT);
	$name = $_POST['name'];
	$family = $_POST['family'];
	$email = $_POST['email'];
	$country = $_POST['country'];

	$user_exist = false;

	$response = array();

	$conn = create_database_connection();
	$user_exist = check_username($conn,$username);
	
	
	if(!$user_exist){
		$insert_string = "Insert into users(username,password,name,family,email,country) 
									value('".$username."','".$password."','".$name."','".$family."','".$email."','".$country."')";
		if($conn['connection']->query($insert_string) === true){
			$response['success'] = true;
		}else{
			$response['success'] = false;
			$response['err_message'] = $insert_string;
		}
	}else{
		$response['success'] = false;
		$response['err_message'] = 'Потребителят съществува. Моля изберете друго потребителско име!';
	}
	$conn['connection']->close();
	
	echo json_encode($response);
}


function update_user(){


	$user_id = $_POST['id'];
	$password = password_hash($_POST['password'],PASSWORD_DEFAULT);
	$name = $_POST['name'];
	$family = $_POST['family'];
	$email = $_POST['email'];
	$country = $_POST['country'];

	

	$response = array();

	$conn = create_database_connection();	
	
	$update_string = "UPDATE users SET password = '".$password."', name = '".$name."', family = '".$family."', email = '".$email."', country = '".$country."' where id = ".$user_id;

	if($conn['connection']->query($update_string) === true){
		$response['success'] = true;
	}else{
		$response['success'] = false;
		$response['err_message'] = $update_string;
	}

	$conn['connection']->close();
	
	echo json_encode($response);
}


function log_user(){
	$username = $_POST['username'];
	$password = $_POST['password'];
	$result = array();

	$conn = create_database_connection();
	$sql = "Select * from users where username = '".$username."'";
	$db_result = $conn['connection']->query($sql);

	if($db_result->num_rows != 1){
		$result['success'] = false;
		$result['error_message'] = 'Не е намерен потребител с такова потребителско име!';
	}else{
		$row = $db_result->fetch_assoc();
		if(password_verify($password,$row['password'])){
			$result['success'] = true;
			$result['error_message'] = '';

			$result['user_data'] = array(
				'username' => $username,
				'password' => $password,
				'name' => $row['name'],
				'family' => $row['family'],
				'email' => $row['email'],
				'country' => $row['country'],
				'id' => $row['id']
			);	
		}else{
			$result['success'] = false;
			$result['error_message'] = 'Въведена е невалидна парола!';
		}
	}

	$conn['connection']->close();
	echo json_encode($result);
}


function load_user_data(){	
	$user_id = $_POST['id'];
	
	
	$sql = "SELECT * FROM users where id = '".$user_id."'";
	$conn = create_database_connection();
	$result = $conn['connection']->query($sql);

	$row = $result->fetch_assoc();
	$conn['connection']->close();


	$url = 'https://openexchangerates.org/api/latest.json/?app_id=63bdb4c96ba54a078ed352811b4ef073';
	$url_nomen = 'https://openexchangerates.org/api/currencies.json/?app_id=63bdb4c96ba54a078ed352811b4ef073';
	
	$response = file_get_contents($url);
	$response_nomen = file_get_contents($url_nomen);
	
	$row['currency'] = $response;
	$row['nomenclature'] = $response_nomen;
	$row['chart_data'] = test_curr($response);

	echo json_encode($row);
	
}

function test_curr($arr){	
	
	$arr = array(
		"AED" => 3.672957, 
		"AFN" => 77.785256, 
		"ALL" => 103.027104, 
		"AMD" => 524.651566, 
		"ANG" => 1.795427
	);
	$res_arr = array();
	$i=0;

	foreach($arr as $key=>$value){
		$i++;
		$res_arr[$i] = array(
						'currency' => $key,
						'val' => $value
					);
	}
	
	return json_encode($res_arr);
}

if(isset($_POST['action']) && $_POST['action'] == 'register'){
	register_user();
}else if(isset($_POST['action']) && $_POST['action'] == 'login'){
	log_user();
}else if(isset($_POST['action']) && $_POST['action'] == 'update'){
	update_user();
}else if(isset($_POST['action']) && $_POST['action'] == 'load'){
	load_user_data();
}

?>